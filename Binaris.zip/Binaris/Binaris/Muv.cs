﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binaris
{
    class Muv
    {
        static byte[] szam1 = new byte[8];
        static byte[] szam2 = new byte[8];

        static int[] bin = { 128, 64, 32, 16, 8, 4, 2, 1 };

        public static void Beolvas()
        {
            int inp = Input();
            szam1 = ToBinConvert(inp);

            inp = Input();
            szam2 = ToBinConvert(inp);
        }

        private static int Input()
        {
            const int MAX_INPUT = 255;
            int inp;
            do
            {
                Console.Write("Kérek egy számot: ");
                inp = int.Parse(Console.ReadLine());
            } while (inp < 0 || MAX_INPUT < inp);

            return inp;
        }

        public static void Kiir()
        {
            Adat(szam1);
            Adat(szam2);
            byte[] sum = BinOsszead(szam1, szam2);
            Console.WriteLine($"Összeg: {ToDecConvert(sum)}, ");
            foreach (byte bit in sum)
            {
                Console.Write(bit);
            }

            Console.WriteLine();
            byte[] s = new byte[8];
            s = LogicAnd(szam1, szam2);
            for (int i = 0; i < s.Length; i++)
            {
                Console.Write(s[i]);
            }

            Console.WriteLine();
            s = LogicOr(szam1, szam2);
            for (int i = 0; i < s.Length; i++)
            {
                Console.Write(s[i]);
            }

            Console.WriteLine();
            s = LogicXor(szam1, szam2);
            for (int i = 0; i < s.Length; i++)
            {
                Console.Write(s[i]);
            }
        }

        private static void Adat(byte[] szam)
        {
            Console.Write("\nBináris formában: ");
            for (int i = 0; i < szam.Length; i++)
            {
                Console.Write(szam[i]);
            }
            Console.WriteLine();

            Console.WriteLine($"Decimális formában: {ToDecConvert(szam)}");
        }

        private static byte[] BinOsszead(byte[] a, byte[] b)
        {
            byte[] eredmeny = new byte[8];
            for (int i = 7; i >= 0; i--)
            {
                if (a[i] == 1 && b[i] == 1)
                {
                    eredmeny[i] = 0;
                    eredmeny[i - 1] = 1;
                }
                else if (a[i] == 1 || b[i] == 1)
                {
                    eredmeny[i] = 1;
                }
                else if (eredmeny[i] != 1)
                {
                    eredmeny[i] = 0;
                }
            }

            return eredmeny;
        }

        private static void BinKivonas(byte[] a, byte[] b)
        {

        }

        private static byte[] ToBinConvert(int szam)
        {
            byte[] tempSzam = new byte[8];
            for (int i = 0; i < szam1.Length; i++)
            {
                tempSzam[i] = Convert.ToByte(szam / bin[i]);
                if (tempSzam[i] == 1)
                {
                    szam -= bin[i];
                }
            }
            
            return tempSzam;
        }

        private static int ToDecConvert(byte[] szam)
        {
            int tempSzam = 0;

            for (int i = 0; i < bin.Length; i++)
            {
                if (szam[i] == 1)
                {
                    tempSzam += bin[i];
                }
            }

            return tempSzam;
        }

        
        public static byte[] LogicOr(byte[] a, byte[] b)
        {
            byte[] temp = new byte[8];
            for (int i = 0; i < temp.Length; i++)
            {
                if (a[i] == 1 || b[i] == 1)
                {
                    temp[i] = 1;
                }
                else
                {
                    temp[i] = 0;
                }
            }

            return temp;
        }

        public static byte[] LogicAnd(byte[] a, byte[] b)
        {
            byte[] temp = new byte[8];
            for (int i = 0; i < temp.Length; i++)
            {
                if (a[i] == 1 && b[i] == 1)
                {
                    temp[i] = 1;
                }
                else
                {
                    temp[i] = 0;
                }
            }

            return temp;
        }

        public static byte[] LogicXor(byte[] a, byte[] b)
        {
            byte[] temp = new byte[8];
            for (int i = 0; i < a.Length; i++)
            {
                if ((a[i] == 1 && b[i] == 0) || (a[i] == 0 && b[i] == 1))
                {
                    temp[i] = 1;
                }
                else
                {
                    temp[i] = 0;
                }
            }

            return temp;
        }
    }
}
