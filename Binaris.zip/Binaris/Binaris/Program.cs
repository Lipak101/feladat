﻿using System;

namespace Binaris
{
    class Program
    {
        static void Main(string[] args)
        {
            Muv.Beolvas();
            Muv.Kiir();
        }
    }
}
