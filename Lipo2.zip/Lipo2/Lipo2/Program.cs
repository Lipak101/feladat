﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Lipo2
{
    class Program
    {
        static void Main(string[] args)
        {
            //TASK1();
            Task2();
        }
        public static void Task2()
        {
            int A = int.Parse(Console.ReadLine());
            int B = int.Parse(Console.ReadLine());

        }
        public static void TASK1()
        {
            Console.WriteLine("Add meg a számot: ");
            string A = ByteConvert(int.Parse(Console.ReadLine()));
            Console.WriteLine($"binary: {A}");
            Console.WriteLine("megint:");
            string B = ByteConvert(int.Parse(Console.ReadLine()));
            Console.WriteLine($"binary: {B}");
            string and = És(A, B);
            Console.WriteLine($"AND: {and}");
            Console.WriteLine($"decimalba: {ToDecimal(and)}");

            string vagy = Vagy(A, B);
            Console.WriteLine($"OR: {vagy}");
            Console.WriteLine($"decimalba: {ToDecimal(vagy)}");

            string xor = XOR(A, B);
            Console.WriteLine($"XOR: {xor}");
            Console.WriteLine($"decimalba: {ToDecimal(xor)}");
        }
        public static int ToDecimal(string binary)
        {
            char[] array = binary.ToCharArray();
            array.Reverse();
            int sum = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i]=='1')
                {
                    if (i==0)
                    {
                        sum += 1;
                    }
                    else
                    {
                        sum += (int)Math.Pow(2, i);
                    }
                }
            }
            return sum;
        }
        public static string ByteConvert(int num)
        {
            int[] p = new int[8];
            string pa = "";
            for (int ii = 0; ii <= 7; ii++)
            {
                p[7 - ii] = num % 2;
                num = num / 2;
            }
            for (int ii = 0; ii <= 7; ii++)
            {
                pa += p[ii].ToString();
            }
            return pa;
        }
        public static string És(string A,string B)
        {
            string result = "";
            for (int i = 0; i < A.Length; i++)
            {
                if (A[i] == '1' && B[i] == '1')
                {
                    result += "1";
                }
                else
                {
                    result += "0";
                }
            }
            return result;
        }
        public static string Vagy(string A , string B)
        {
            string result = "";
            for (int i = 0; i < A.Length; i++)
            {
                if (A[i]=='1'||B[i]=='1')
                {
                    result += "1";
                }
                else
                {
                    result += "0";
                }
            }
            return result;
        }
        public static string XOR(string A, string B)
        {
            string result = "";
            for (int i = 0; i < A.Length; i++)
            {
                if ((A[i] == '1' &&B[i]=='0')||(A[i]=='0'&&B[i]=='1'))
                {
                    result += "1";
                }
                else
                {
                    result += "0";
                }
            }
            return result;
        }
    }
}
